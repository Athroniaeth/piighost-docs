# @piighost/ui

The Svelte 5 components every piighost surface shares, in the v3 identity:
the navigation bar and footer, buttons, code blocks and uv/pip install tabs,
entity chips, and the documentation blocks of `docs.piighost.dev` (admonitions,
synced tabs, identifier links with hover cards, sidebar, table of contents, and
the renderer of build-time Markdown trees).

The tokens are not written here. `src/lib/theme.css` is generated in
`piighost-identite` and copied by `pnpm tokens`; `pnpm tokens:check` fails when
the copy drifts.

## Use

```css
/* app.css */
@import '@piighost/ui/styles.css';
```

```svelte
<script>
	import { SiteNav, ThemeToggle, CodeBlock } from '@piighost/ui';
</script>
```

Load `static/theme.js` in the page head, before first paint: dark is the default.

## Develop

```bash
pnpm install
pnpm dev                                  # the showcase page
pnpm storybook                            # every component, with axe checks
pnpm exec vitest run --project storybook  # the stories as tests
pnpm build                                # svelte-package and publint
```

The rules for writing a component are in `skills/piighost-ui/SKILL.md`.
